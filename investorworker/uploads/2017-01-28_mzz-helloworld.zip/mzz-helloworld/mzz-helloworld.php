<?php
/*
Plugin Name: mzz-helloworld
Description: A hello world plugin for WordPress
License: GPLv2
*/

load_plugin_textdomain('mzz-helloworld', false, plugin_basename(dirname(__FILE__)). '/languages');

// echoes the text
function mzz_helloworld() {
	echo __("Hello, Mzz World!", 'mzz-helloworld');
}

// execute when the admin_notices action is called, thus the text shows at top of WP Admin Dashboard area
add_action( 'admin_notices', 'mzz_helloworld' );

?>
